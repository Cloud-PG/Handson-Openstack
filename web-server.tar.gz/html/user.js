
$DOC.mod('theme-switcher');

// example of using $DOC.parseContent function to create sections
$DOC.parseContent(function(){/*

<!--fixed-top-bar
[navbar]
[Home]({{=$DOC.root}}index.html)
***
* [Introduction]({{=$DOC.root}}index.html)
 * [General notions]({{=$DOC.root}}introduction/introduction.html)
 * [Glossary]({{=$DOC.root}}introduction/glossary.html)
 * [Openstack services]({{=$DOC.root}}introduction/services.html)
 * [Dashboard usage]({{=$DOC.root}}introduction/dashboard.html)
* [Networking]({{=$DOC.root}}network.html)
* [VM Creation]({{=$DOC.root}}instance-creation.html)
* [Port Mapping]({{=$DOC.root}}security-groups.html)
* [Example]({{=$DOC.root}}web-server.html)
* [Advanced Examples]({{=$DOC.root}}index.html)
 * [Heat introduction]({{=$DOC.root}}advanced-examples/heat-base.html)
 * [Heat template example]({{=$DOC.root}}advanced-examples/heat-advanced.html)
[/navbar]
-->

<!--header-panel

# Openstack Hands-on

-->

*/});

// another example of creating a named section
$DOC.sections['footer-panel'] =
'[footer-layout scheme=line]\
* Author: Manuel Ciangottini\n\
***\n\
* [Openstack Handson github repository](https://github.com/Cloud-PG/Handson-Openstack)\
[/footer-layout]';
